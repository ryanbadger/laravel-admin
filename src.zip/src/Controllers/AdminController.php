<?php

namespace RyanBadger\LaravelAdmin\Controllers;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use Illuminate\Support\Str;

class AdminController extends Controller
{
    public function dashboard()
    {
        $models = config('admin_module.models');  // Assuming 'models' contains all the models you want to manage
        $modelData = [];

        foreach ($models as $key => $value) {
            $modelClass = $value['class'];
            if (class_exists($modelClass)) {
                $modelData[$key] = [
                    'count' => $modelClass::count(),
                    'name' => Str::plural(ucfirst($key))
                ];
            }
        }

        return view('laravel-admin::admin.dashboard', compact('modelData'));
    }


    public function settings()
    {
        return view('laravel-admin::admin.settings');
    }
    
    public function index($model)
    {
        $modelClass = $this->getModelClass($model);
        $records = $modelClass::all();
        $fields = $this->getFields($model);
        return view('laravel-admin::admin.index', compact('records', 'model', 'fields'));
    }

    public function create($model)
    {
        $modelClass = $this->getModelClass($model);
        $fields = $this->getFields($model);
        return view('laravel-admin::admin.form', compact('model', 'fields'));
    }

    public function store(Request $request, $model)
    {
        $modelClass = $this->getModelClass($model);
        $validationRules = $this->getValidationRules($model);
        $validatedData = $request->validate($validationRules);
        $record = $modelClass::create($validatedData);
        return redirect()->route('admin.index', $model)->with('success', 'Record created successfully!');
    }

    public function edit($model, $id)
    {
        $modelClass = $this->getModelClass($model);
        $record = $modelClass::findOrFail($id);
        $fields = $this->getFields($model);
        return view('laravel-admin::admin.form', compact('model', 'record', 'fields'));
    }

    public function update(Request $request, $model, $id)
    {
        $modelClass = $this->getModelClass($model);
        $validationRules = $this->getValidationRules($model);
        $validatedData = $request->validate($validationRules);
        $record = $modelClass::findOrFail($id);
        $record->update($validatedData);
        return redirect()->route('admin.index', $model)->with('success', 'Record updated successfully!');
    }

    public function destroy($model, $id)
    {
        $modelClass = $this->getModelClass($model);
        $record = $modelClass::findOrFail($id);
        $record->delete();
        return redirect()->route('admin.index', $model)->with('success', 'Record deleted successfully!');
    }

    private function getModelClass($model)
    {   

        $models = config('admin_module.models');

        $modelClass = $models[$model]['class'] ?? null;

        return $modelClass ? $modelClass : abort(404);
    }

    private function getFields($model)
    {
        $models = config('admin_module.models');
        $modelConfig = $models[$model] ?? null;

        if ($modelConfig) {
            return $modelConfig['fields'] ?? [];
        }

        return [];
    }


    private function getValidationRules($model)
    {
        $models = config('admin_module.models');
        $modelConfig = $models[$model] ?? null;

        if ($modelConfig) {
            return $modelConfig['validation'] ?? [];
        }

        return [];
    }
}